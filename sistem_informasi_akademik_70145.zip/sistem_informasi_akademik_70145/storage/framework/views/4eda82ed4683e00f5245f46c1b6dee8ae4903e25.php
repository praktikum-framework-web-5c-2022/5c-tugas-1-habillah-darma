
<?php $__env->startSection('title','Mahasiswa'); ?>
<?php $__env->startSection('active2','active'); ?>
<?php $__env->startSection('judulhalaman','Mahasiswa 5C Teknik Informatika 2022 UNSIKA'); ?>
<?php $__env->startSection('daftar'); ?>
<div class="container">
    <ol class="list-group list-group-flush">
        <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item"><?php echo e($mhs); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem_informasi_akademik_70145\resources\views/mahasiswa.blade.php ENDPATH**/ ?>