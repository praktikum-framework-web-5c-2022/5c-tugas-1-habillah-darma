
<?php $__env->startSection('title','Mata Kuliah'); ?>
<?php $__env->startSection('active3','active'); ?>
<?php $__env->startSection('judulhalaman','Mata Kuliah Semester Ganjil 2022 UNSIKA'); ?>
<?php $__env->startSection('daftar'); ?>
<div class="container">
    <ol class="list-group list-group-flush">
        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item"><?php echo e($mk); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem_informasi_akademik_70145\resources\views/matakuliah.blade.php ENDPATH**/ ?>